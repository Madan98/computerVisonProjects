import numpy as np
from PIL import Image 
import os
import cv2
from colocode import getLimits

yellow=[0,255,255]
#capyuring the video using inbuilt camera
capturedVideo=cv2.VideoCapture(0)

while True:
    #reading the captured video to get each frames and showing it
    ret,frame = capturedVideo.read()
    
    #to betterly identify the image, convert it to csv from bgr
    hsvImage=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)

    lowerLimit,upperLimit= getLimits(color=yellow)
    
    mask=cv2.inRange(hsvImage,lowerLimit,upperLimit)
    maskToImage=Image.fromarray(mask)
    bbox=maskToImage.getbbox()
    
    if bbox is not None:
        x1,y1,x2,y2=bbox
        frame=cv2.rectangle(frame,(x1,y1),(x2,y2),(0,255,0),5)
    
    cv2.imshow("Frame",frame)
    
    #waitkey checks weather a operation like pressing 'q' happend every 1millisecond and then generates asci value of the key and next we will compare with q 
    key=cv2.waitKey(1)
    if key & 0xFF==ord('q'):
      break
capturedVideo.release()
cv2.destroyAllWindows()
